package com.aperto.assignment.ClientService;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.security.oauth2.client.token.grant.client.ClientCredentialsResourceDetails;
import org.springframework.web.client.RestTemplate;

/**
 * This class bootstraps the Client Service application, and configures the 
 * 
 * @author nunem
 *
 */

@SpringBootApplication
public class ApertoClientServiceApplication implements CommandLineRunner{
	
	private static final String PROPERTY_NAME_URL = "http://localhost:8082/private";

	public static void main(String[] args) {
		SpringApplication.run(ApertoClientServiceApplication.class, args);
	}
	
	@Bean
	@ConfigurationProperties("security.oauth2.client")
	public ClientCredentialsResourceDetails oAuthDetails() {
		return new ClientCredentialsResourceDetails();
	}
	
	@Bean
	public RestTemplate restTemplate() {
		return new OAuth2RestTemplate(oAuthDetails());
	}

	@Override
	public void run(String... args) throws Exception {
		String result= restTemplate().getForObject(PROPERTY_NAME_URL, String.class);
	}
	
	

}
