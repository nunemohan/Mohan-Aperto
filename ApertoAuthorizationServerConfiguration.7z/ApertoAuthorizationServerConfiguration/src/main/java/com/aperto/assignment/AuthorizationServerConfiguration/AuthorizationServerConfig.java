package com.aperto.assignment.AuthorizationServerConfiguration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.config.annotation.configurers.ClientDetailsServiceConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configuration.AuthorizationServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerEndpointsConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.security.oauth2.provider.token.store.InMemoryTokenStore;

/**
 * The Component for configuring the authorization server, which issues access tokens to the client after 
 * successfully authenticating the resource owner and obtaining authorization.
 * 
 * @author nunem
 *
 */

@Configuration
public class AuthorizationServerConfig extends AuthorizationServerConfigurerAdapter {
	
	@Autowired
	PasswordEncoder encoder;
	
	@Autowired
	TokenStore tokenStore;
	
	@Autowired
	@Qualifier("authenticationManagerBean")
	AuthenticationManager authenticationManager;
	
	/**
	 * This method configures the security of the Authorization Server, like /oauth/token endpoint.
	 */
	@Override
    public void configure(AuthorizationServerSecurityConfigurer security) throws Exception {

        security.checkTokenAccess("isAuthenticated()");
    }

	
	/**
	 * This method configures the individual client details and their properties
	 */
    @Override
    public void configure(ClientDetailsServiceConfigurer clients) throws Exception {
		
		  clients .inMemory() .withClient("client") .secret(encoder.encode("secret"))
		  .authorizedGrantTypes("password") .scopes("all") .and().
		  withClient("resourceserver").secret(encoder.encode("secret")).authorizedGrantTypes("password").scopes("all")
		  .and().withClient("clientserver").secret(encoder.encode("secret")).authorizedGrantTypes("clientlogin").scopes("all");
		 
    }

    /**
     * This method configure the non-security features of the Authorization Server end points, like token store.
     */
    @Override
    public void configure(AuthorizationServerEndpointsConfigurer endpoints) throws Exception {
        endpoints.tokenStore(tokenStore).authenticationManager(authenticationManager);
    }


    @Bean
    TokenStore tokenStore() {
    	return new InMemoryTokenStore();
    }

    @Bean
    PasswordEncoder passwordEncoder() {
    	return new BCryptPasswordEncoder();
    }
}
