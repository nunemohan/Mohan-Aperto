package com.aperto.assignment.AuthorizationServerConfiguration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

/**
 * This class is used for customizing user details.
 * 
 * @author nunem
 *
 */
public class CustomUserDetailsService implements UserDetailsService{
	
	@Autowired
	AccountRepository accRepository;
	
	@Autowired
	PasswordEncoder encoder;
	

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		return accRepository.findByUsername(username).map(account -> new User(account.getUsername(), encoder.encode(account.getPassword()), 
				true, true, true, true,
				AuthorityUtils.createAuthorityList("write","read"))).orElseThrow(()-> new UsernameNotFoundException("User Doesn't Exist"));
	}
	
	 @Bean
	    PasswordEncoder passwordEncoder() {
	    	return new BCryptPasswordEncoder();
	    }
}
	

