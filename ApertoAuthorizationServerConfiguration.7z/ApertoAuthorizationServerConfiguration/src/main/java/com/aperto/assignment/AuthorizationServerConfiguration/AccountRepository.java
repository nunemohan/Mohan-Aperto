package com.aperto.assignment.AuthorizationServerConfiguration;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * An Account Repository to store the user credentials.
 * 
 * @author nunem
 *
 */

@Repository
public interface AccountRepository extends JpaRepository<Account, Integer>{
	
	Optional<Account> findByUsername(String username);
	
}
