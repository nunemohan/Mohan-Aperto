package com.aperto.assignment.AuthorizationServerConfiguration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableAuthorizationServer;

/**
 * This class bootstraps the AuthorizationServerConfiguration Application.
 * 
 * @author nunem
 *
 */

@EnableAuthorizationServer
@SpringBootApplication
public class AuthorizationServerConfigurationApplication implements CommandLineRunner{
	
	private static final String PROPERTY_USER_NAME = "mohan";
	private static final String PROPERTY_PASSWORD = "1234";
	
	@Autowired
	AccountRepository accountRepository;	
	
	public static void main(String[] args) {
		SpringApplication.run(AuthorizationServerConfigurationApplication.class, args);
	}
	
	/**
	 * This method deletes the user details and inserts the credentils on every server start.
	 */
	@Override
	public void run(String... args) throws Exception {
		accountRepository.deleteAll();
		accountRepository.save(new Account(PROPERTY_USER_NAME, PROPERTY_PASSWORD));
	}
	

}
