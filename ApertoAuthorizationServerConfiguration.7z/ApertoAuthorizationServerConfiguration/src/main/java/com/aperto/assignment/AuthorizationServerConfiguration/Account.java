package com.aperto.assignment.AuthorizationServerConfiguration;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 * Account Entity to store the user credentials for login.
 * 
 * @author nunem
 *
 */
@Entity
public class Account {
	
	 
	/**
	 * The property to hold the Id.
	 */
	@Id
	@GeneratedValue
	private Integer id;	

	/**
	 * The property to hold the user name.
	 */
	private String username;
	
	/**
	 * The property to hold the password.
	 */	
	private String password;
	
	
	/**
	 * No-arg Constructor
	 */
	public Account() {

	}
	
	/**
	 * Constructor
	 * 
	 * @param username
	 * @param password
	 */
	public Account(String username, String password) {
		this.username = username;
		this.password = password;
	}
	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}
	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}
	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	
}
