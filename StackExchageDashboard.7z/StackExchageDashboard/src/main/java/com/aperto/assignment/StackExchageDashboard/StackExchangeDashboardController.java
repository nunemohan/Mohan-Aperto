package com.aperto.assignment.StackExchageDashboard;

import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.aperto.assignment.Item;
import com.aperto.assignment.Items;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * The Controller component reads the JSON data and filter the url links based on the given keyword
 * 
 * @author nunem
 *
 */

@Controller
public class StackExchangeDashboardController {
	
	Logger logger = LoggerFactory.getLogger(StackExchangeDashboardController.class);
	
	private static final String JSON_FILE_PATH = "/json/items.json";
	
	private static final String MODEL_ATTRIBUTE_LINK_MAP = "linkMap";
	
	@Value("${core.media.keyword}")
	private String keyWord;
	
	 @RequestMapping("/stackexchangelinks")
	 public String fetchUrlLinks(Model model) {
		 
		 Map<String, String> linkItemMap = new HashMap<String, String>();
	        
			ObjectMapper mapper = new ObjectMapper();
			TypeReference<Items> typeReference = new TypeReference<Items>(){};
			InputStream inputStream = TypeReference.class.getResourceAsStream(JSON_FILE_PATH);
			try {
				//reads the JSON data
				Items items = mapper.readValue(inputStream,typeReference);
				
				keyWord = keyWord.toLowerCase();
				
				//filter the url links based on keyword
				List<Item> filterdItems = items.getItems().stream().filter(item->item.getLink().contains(keyWord)).collect(Collectors.toList()); 
				filterdItems.forEach(linkItem -> linkItemMap.put(linkItem.getTitle(), linkItem.getLink()));	
				
				model.addAttribute(MODEL_ATTRIBUTE_LINK_MAP, linkItemMap);
				
			} catch (Exception exception){
				logger.error(exception.getMessage());
			}
				
	        return "stackexchangelinks";
	    }
	 
	 

	/*
	 * @RequestMapping("/stackexchangelinks") public String fetchUrlLinks(Model
	 * model) { RestTemplate restTemplate = new RestTemplate(); String uri=
	 * "https://api.stackexchange.com/2.2/search?page=1&pagesize=10&fromdate=1478390400&todate=1563753600&order=desc&min=1454457600&max=1563753600&sort=activity&intitle=coremedia&site=stackoverflow";
	 * 
	 * HttpHeaders headers = new HttpHeaders();
	 * headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
	 * headers.add("Accept-Encoding", "application/gzip"); HttpEntity<Object> entity
	 * = new HttpEntity<Object>(headers);
	 * 
	 * 
	 * byte[] responseBytes = restTemplate .exchange(uri, HttpMethod.GET, entity,
	 * byte[].class).getBody(); String decompressed = null; try { decompressed= new
	 * String(CompressionUtil.decompressGzipByteArray(responseBytes)); } catch
	 * (Exception e) { e.printStackTrace(); } }
	 */
	 

}
