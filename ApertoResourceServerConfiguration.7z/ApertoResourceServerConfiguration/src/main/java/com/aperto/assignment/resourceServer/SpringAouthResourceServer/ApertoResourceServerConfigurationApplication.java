package com.aperto.assignment.resourceServer.SpringAouthResourceServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;

/**
 * This class bootstraps the Resource Server Application
 * 
 * @author nunem
 *
 */
@EnableResourceServer
@SpringBootApplication
public class ApertoResourceServerConfigurationApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApertoResourceServerConfigurationApplication.class, args);
	}

}
