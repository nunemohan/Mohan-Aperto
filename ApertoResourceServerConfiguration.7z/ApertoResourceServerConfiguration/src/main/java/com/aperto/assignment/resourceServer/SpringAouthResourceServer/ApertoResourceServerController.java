package com.aperto.assignment.resourceServer.SpringAouthResourceServer;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * The class maps the resource server end points to access the corresponding methods.
 * 
 * @author nunem
 *
 */
@RestController
public class ApertoResourceServerController {
	
	@GetMapping(value="/public")
	public String getTaskStatus() {
		return "I am doing the task.";
	}	
	
	@GetMapping(value="/private")
	public String getTaskInfo() {
		return "I done the task.";
	}

}
